# StampTrail 🗺️✨

**StampTrail** is a location-based Augmented Reality (AR) application that allows users to explore their surroundings, navigate to specific points of interest, and collect virtual "Stamps" using an AR camera overlay.

This project demonstrates a full-stack implementation of mobile geolocation, AR visualization, and secure user authentication.



## 📱 Features

### 📍 Interactive Mapping & Navigation
* **Real-time GPS Tracking:** Tracks user location with high accuracy.
* **Smart Routing:** Draws navigation paths from user location to destination markers (supports Google Maps Directions API with fallback to geodesic lines).
* **Manual Mode:** Fallback functionality allows users to "pin" their location manually for testing without GPS.
* **Custom UI:** Fully customized map markers and distinct "Go/Cancel" navigation states.

### 👓 Augmented Reality (AR)
* **Camera Integration:** Seamlessly switches from Map View to AR View.
* **AR Overlays:** Renders virtual objects (Stamps) into the real world using the device camera.
* **Permission Handling:** Robust handling of camera and location permissions.

### 🔐 Authentication & Onboarding
* **Phone Auth Flow:** Simulated OTP (One-Time Password) verification system.
* **User Profiling:** Dedicated signup flow for capturing user details (Name, Username).
* **Secure Storage:** (Planned) Secure token management for user sessions.



## 🛠️ Tech Stack

* **Frontend:** React Native, Expo (SDK 50+)
* **Navigation:** React Navigation (Stack)
* **Maps:** `react-native-maps`, `react-native-maps-directions`
* **Camera/AR:** `expo-camera`
* **Backend:** Node.js / Express (API) *[or Python/Flask - edit as needed]*

```text

## 📂 Project Structure

This repository is structured as a monorepo containing both the mobile client and the backend server.


StampTrail-FullStack/
├── StampTrail/          # React Native Mobile Application
│   ├── screens/         # UI Screens (Login, Map, AR, Signup)
│   ├── App.js           # Main Entry Point & Navigation
│   ├── app.json         # Expo Configuration
│   └── package.json     # Frontend Dependencies
│
├── stamptrail-backend/             # Server API
│   ├── server.js        # API Entry Point
│   └── package.json     # Backend Dependencies
│
└── README.md            # Project Documentation


🚀 Getting Started
Follow these instructions to run the project locally.

Prerequisites
Node.js installed

Expo Go app installed on your physical device (iOS/Android)

1. Setup the Backend
Open a terminal in the backend folder:

Bash

cd stamptrail-backend
npm install
node server.js
The server will start on port 5000.

2. Run the Mobile App
Open a new terminal in the StampTrail folder:

Bash

cd StampTrail
npm install
npx expo start --clear
Scan the QR code with the Expo Go app on your phone.

Ensure your phone and computer are on the same Wi-Fi network.
```


### 📸 Screenshots
### Login & Auth
<img src="https://github.com/user-attachments/assets/5ef0fba7-a7ac-4315-b9cd-6fbc045b0976" width='200'>
<img src="https://github.com/user-attachments/assets/e8748541-9259-4d74-b5cb-b73227480cfe" width='200'>

### SignUp
<img src="https://github.com/user-attachments/assets/348620e8-0b32-4f2a-80f7-17c77bb355bc" width='200'>

### Interactive Map
<img src="https://github.com/user-attachments/assets/9a971776-ab82-41df-ae0c-9a3cbafc0781" width='200'>

### AR View
<img src="https://github.com/user-attachments/assets/871e15b4-32e9-42a4-8231-9535dd390a80" width='200'>


⚠️ Note to Reviewers
Google Maps API Key: The project is currently configured to use a development key or fallback mode. To enable full turn-by-turn routing, add a valid API key in screens/MapScreen.js.

AR Testing: AR features require a physical device with camera permissions enabled (Simulators/Emulators do not support camera).

Author
Karim Hasan | www.linkedin.com/in/abdul-karim-hasan-562838385 
