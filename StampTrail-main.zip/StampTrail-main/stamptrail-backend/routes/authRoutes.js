
const express = require('express');
const router = express.Router();
const { User } = require('../models/Index');


router.post('/login', async (req, res) => {
  const { email } = req.body;
  try {

    const [user, created] = await User.findOrCreate({ where: { email } });
    

    const code = Math.floor(1000 + Math.random() * 9000).toString();
    
   
    user.twoFactorCode = code;
    await user.save();

    console.log(`[DEV ONLY] Code for ${email}: ${code}`); 
    res.json({ message: "Code sent", userId: user.id });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});


router.post('/verify', async (req, res) => {
  const { email, code } = req.body;
  try {
    const user = await User.findOne({ where: { email } });
    
    if (user && user.twoFactorCode === code) {
     
      user.twoFactorCode = null;
      await user.save();
      res.json({ success: true, user });
    } else {
      res.status(400).json({ success: false, message: "Invalid Code" });
    }
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;