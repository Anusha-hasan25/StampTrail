
const express = require('express');
const cors = require('cors');
const { sequelize } = require('./models/Index');
const authRoutes = require('./routes/authRoutes');

const app = express();


app.use(cors());
app.use(express.json());


app.use('/api/auth', authRoutes);


const PORT = process.env.PORT || 5000;

sequelize.sync({ force: false }) 
  .then(() => {
    console.log('Database connected & synced');
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  })
  .catch((err) => console.log('DB Error:', err));