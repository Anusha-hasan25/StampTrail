
const sequelize = require('../config/db');
const User = require('./User');
const Stamp = require('./Stamp');


User.hasMany(Stamp);
Stamp.belongsTo(User);

module.exports = { sequelize, User, Stamp };