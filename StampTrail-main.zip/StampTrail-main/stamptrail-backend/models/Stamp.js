
const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const Stamp = sequelize.define('Stamp', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true
  },
  latitude: {
    type: DataTypes.FLOAT,
    allowNull: false
  },
  longitude: {
    type: DataTypes.FLOAT,
    allowNull: false
  },
  message: {
    type: DataTypes.STRING,
    allowNull: true
  },
  isCollected: {
    type: DataTypes.BOOLEAN,
    defaultValue: false
  }
});

module.exports = Stamp;