import React, { useState } from 'react';
import { 
  View, Text, TextInput, TouchableOpacity, StyleSheet, 
  SafeAreaView, StatusBar, KeyboardAvoidingView, Platform, 
  TouchableWithoutFeedback, Keyboard, Alert 
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const THEME = {
  bg: '#3A005B',        
  inputBg: '#592474',   
  accent: '#A0F0A0',    
  text: '#FFFFFF',      
  textSec: '#D1C4E9',   
};

export default function SignupDetailsScreen({ navigation }) {
  const [fullName, setFullName] = useState('');
  const [username, setUsername] = useState('');
  const [loading, setLoading] = useState(false);

  const handleCompleteSignup = () => {
    if (fullName.length < 3 || username.length < 3) {
      Alert.alert("Incomplete", "Please enter a valid name and username.");
      return;
    }

    setLoading(true);

    setTimeout(() => {
      setLoading(false);
      navigation.replace('MapScreen'); 
    }, 1500);
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" />
      <KeyboardAvoidingView 
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'} 
        style={{ flex: 1 }}
      >
        <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
          <View style={styles.content}>
            
            <View style={{ marginTop: 40, marginBottom: 20 }}>
                
            </View>

            
            <View style={styles.headerArea}>
              <Text style={styles.logoText}>StampTrail</Text>
              <Text style={styles.headerTitle}>Create your profile</Text>
              <Text style={styles.headerSubtitle}>Tell your friends who you are</Text>
            </View>

            {/* --- SIGNUP FORM --- */}
            <View style={styles.formArea}>
              
              {/* Full Name Input */}
              <View style={styles.inputContainer}>
                <Text style={styles.inputLabel}>Full Name</Text>
                <TextInput
                  style={styles.textInput}
                  placeholder="e.g. John Doe"
                  placeholderTextColor={THEME.textSec}
                  value={fullName}
                  onChangeText={setFullName}
                  autoCapitalize="words"
                />
              </View>

              {/* Username Input */}
              <View style={styles.inputContainer}>
                <Text style={styles.inputLabel}>Username</Text>
                <TextInput
                  style={styles.textInput}
                  placeholder="e.g. StampHunter"
                  placeholderTextColor={THEME.textSec}
                  value={username}
                  onChangeText={setUsername}
                  autoCapitalize="none"
                />
              </View>

              {/* "Complete" Button */}
              <TouchableOpacity style={styles.mainBtn} onPress={handleCompleteSignup} disabled={loading}>
                <Text style={styles.btnText}>
                    {loading ? "Creating Profile..." : "Complete Signup"}
                </Text>
              </TouchableOpacity>

            </View>
            
            {/* Footer */}
            <View style={{flex: 1, justifyContent: 'flex-end', marginBottom: 0}}>
              <Text style={styles.footerText}>A StampTrail Product</Text>
            </View>

          </View>
        </TouchableWithoutFeedback>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: THEME.bg },
  content: { flex: 1, paddingHorizontal: 20 },
  
  // Header Styles
  headerArea: { alignItems: 'center', marginBottom: 40 },
  logoText: { color: THEME.accent, fontSize: 24, fontWeight: 'bold', letterSpacing: -0.5, marginBottom: 40 },
  headerTitle: { color: 'white', fontSize: 28, fontWeight: '600', marginBottom: 10 },
  headerSubtitle: { color: THEME.textSec, fontSize: 16 },

  // Form Styles
  formArea: { marginTop: 20 },
  inputContainer: { marginBottom: 25 },
  inputLabel: { color: 'white', fontSize: 16, fontWeight: '600', marginBottom: 10, marginLeft: 5 },
  

  textInput: { 
    backgroundColor: THEME.inputBg, 
    height: 55, 
    borderRadius: 12, 
    paddingHorizontal: 15,
    fontSize: 18, color: 'white', fontWeight: '500'
  },

  
  mainBtn: { 
    backgroundColor: THEME.accent, 
    height: 55, 
    borderRadius: 30, 
    justifyContent: 'center', alignItems: 'center',
    marginTop: 20, marginBottom: 20
  },
  btnText: { color: '#004d40', fontSize: 18, fontWeight: 'bold' },

  footerText: { color: 'white', textAlign: 'center', fontSize: 14, opacity: 0.7 },
});