import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Dimensions } from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera'; 
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';

const { width, height } = Dimensions.get('window');

const THEME = {
  purple: '#6C4AB6',
  cardBg: '#8D72E1',
  text: '#FFFFFF',
};

export default function ARScreen({ navigation }) {
  const [permission, requestPermission] = useCameraPermissions();

  if (!permission) return <View />;
  if (!permission.granted) {
    return (
      <View style={styles.container}>
        <Text style={{ textAlign: 'center', marginBottom: 20 }}>Camera permission required.</Text>
        <TouchableOpacity onPress={requestPermission} style={styles.permBtn}>
           <Text style={{color: 'white'}}>Grant Permission</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <CameraView style={styles.camera} facing="back">
        
        {/* --- SIMULATED AR STAMP --- */}
        <View style={styles.arOverlay}>
           <View style={styles.cylinder} />
        </View>

        {/* --- BOTTOM INFO CARD --- */}
        <View style={styles.infoCard}>
          <Text style={styles.cardTitle}>Walk into the{'\n'}stamp to collect it</Text>
        </View>

        {/* --- BOTTOM CONTROLS --- */}
        <View style={styles.bottomControls}>
          <View style={styles.toggleGroup}>
            <TouchableOpacity 
              style={styles.toggleBtn} 
              onPress={() => navigation.navigate('MapScreen')}
            >
              <Ionicons name="location-outline" size={20} color="#888" />
            </TouchableOpacity>
            <TouchableOpacity style={[styles.toggleBtn, styles.activeToggle]}>
              <MaterialCommunityIcons name="augmented-reality" size={20} color={THEME.purple} />
            </TouchableOpacity>
          </View>

          <TouchableOpacity 
            style={styles.closeButton} 
            onPress={() => navigation.goBack()}
          >
             <Ionicons name="close" size={24} color="white" />
          </TouchableOpacity>
        </View>
      </CameraView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center' },
  camera: { flex: 1 },
  permBtn: { padding: 15, backgroundColor: THEME.purple, borderRadius: 10, alignSelf: 'center' },
  
  arOverlay: { 
    ...StyleSheet.absoluteFillObject, 
    justifyContent: 'center', alignItems: 'center', zIndex: 1
  },
  cylinder: {
    width: 100, height: height * 0.6, 
    backgroundColor: 'rgba(141, 114, 225, 0.6)', 
    borderRadius: 50, transform: [{ scaleX: 1.2 }] 
  },

  infoCard: {
    position: 'absolute', bottom: 120, alignSelf: 'center',
    width: width - 40, backgroundColor: THEME.cardBg,
    borderRadius: 15, padding: 20, zIndex: 10, elevation: 5
  },
  cardTitle: { color: 'white', fontSize: 22, fontWeight: 'bold', lineHeight: 28 },

  bottomControls: {
    position: 'absolute', bottom: 40, 
    width: '100%', flexDirection: 'row', 
    justifyContent: 'space-between', paddingHorizontal: 20,
    alignItems: 'flex-end', zIndex: 10
  },
  toggleGroup: {
    flexDirection: 'row', backgroundColor: 'white',
    borderRadius: 12, padding: 5, elevation: 5
  },
  toggleBtn: { padding: 10, borderRadius: 8, marginHorizontal: 2 },
  activeToggle: { backgroundColor: '#F0EFFB' },
  
  closeButton: {
    backgroundColor: '#333', width: 50, height: 50,
    borderRadius: 15, justifyContent: 'center', alignItems: 'center', elevation: 5
  },
});