import React, { useState, useEffect } from 'react';
import { 
  View, Text, TextInput, TouchableOpacity, StyleSheet, 
  SafeAreaView, StatusBar, KeyboardAvoidingView, Platform, 
  TouchableWithoutFeedback, Keyboard 
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

// --- THEME ---
const THEME = {
  bg: '#3A005B',        
  inputBg: '#592474',   
  accent: '#A0F0A0',    
  text: '#FFFFFF',      
  textSec: '#D1C4E9',   
};

export default function LoginScreen({ navigation }) {
  const [step, setStep] = useState(0); // 0 = Splash, 1 = Phone, 2 = OTP
  const [isSignup, setIsSignup] = useState(false); // <--- NEW TOGGLE STATE
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [loading, setLoading] = useState(false);

  // 1. Simulate Splash Screen
  useEffect(() => {
    setTimeout(() => {
      setStep(1); 
    }, 2000);
  }, []);

  // 2. Mock API Call
  const handleGetCode = () => {
    if (phone.length < 10) {
      alert("Please enter a valid phone number");
      return;
    }
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setStep(2); // Move to OTP
    }, 1500);
  };

  const handleVerify = () => {
    if (otp === '123456') {
      // IF SIGNUP: Go to Profile Creation
      // IF LOGIN: Go directly to Map (or check backend)
      if (isSignup) {
        navigation.replace('SignupDetails');
      } else {
        // For now, let's assume login also goes to Map directly
        navigation.replace('MapScreen'); 
      }
    } else {
      alert("Invalid Code (Try 123456)");
    }
  };

  // --- RENDER: SPLASH SCREEN ---
  if (step === 0) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
        <StatusBar barStyle="light-content" />
        <Text style={styles.logoText}>StampTrail</Text>
      </View>
    );
  }

  // --- RENDER: MAIN SCREENS ---
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" />
      <KeyboardAvoidingView 
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'} 
        style={{ flex: 1 }}
      >
        <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
          <View style={styles.content}>
            
            {/* Back Button (Only for OTP) */}
            {step === 2 && (
              <TouchableOpacity onPress={() => setStep(1)} style={styles.backBtn}>
                <Ionicons name="chevron-back" size={28} color="white" />
              </TouchableOpacity>
            )}

            {/* Logo Area - Changes based on Login/Signup */}
            <View style={styles.headerArea}>
              {step === 1 && (
                <>
                  <Text style={styles.welcomeText}>
                    {isSignup ? "Start your journey with" : "Welcome back to"}
                  </Text>
                  <Text style={styles.logoText}>StampTrail</Text>
                </>
              )}
            </View>

            {/* --- STEP 1: PHONE INPUT --- */}
            {step === 1 && (
              <View style={styles.formArea}>
                <View style={styles.phoneRow}>
                  <View style={styles.countryCode}>
                    <Text style={styles.inputText}>+92</Text>
                  </View>
                  <TextInput
                    style={styles.phoneInput}
                    placeholder="Phone number"
                    placeholderTextColor={THEME.textSec}
                    keyboardType="phone-pad"
                    value={phone}
                    onChangeText={setPhone}
                  />
                </View>

                {/* Main Action Button */}
                <TouchableOpacity style={styles.mainBtn} onPress={handleGetCode}>
                  <Text style={styles.btnText}>
                    {loading ? "Sending..." : (isSignup ? "Create Account" : "Log In")}
                  </Text>
                </TouchableOpacity>

                <Text style={styles.legalText}>
                  By proceeding, you agree StampTrail may send you texts with notifications and security codes.
                </Text>

                {/* --- NEW SIGNUP / LOGIN TOGGLE BUTTON --- */}
                <View style={styles.toggleContainer}>
                    <Text style={styles.toggleText}>
                        {isSignup ? "Already have an account?" : "Don't have an account?"}
                    </Text>
                    <TouchableOpacity onPress={() => setIsSignup(!isSignup)}>
                        <Text style={styles.toggleBtnText}>
                            {isSignup ? " Log In" : " Sign Up"}
                        </Text>
                    </TouchableOpacity>
                </View>

              </View>
            )}

            {/* --- STEP 2: OTP INPUT --- */}
            {step === 2 && (
              <View style={styles.formArea}>
                <Text style={styles.otpHeader}>
                  Enter the code sent to +92-{phone}
                </Text>

                <View style={styles.otpContainer}>
                  <TextInput
                    style={styles.hiddenInput}
                    keyboardType="number-pad"
                    maxLength={6}
                    onChangeText={(text) => {
                      setOtp(text);
                      if (text.length === 6) handleVerify(); 
                    }}
                    autoFocus={true}
                  />
                  {[0, 1, 2, 3, 4, 5].map((i) => (
                    <View key={i} style={[
                      styles.otpBox, 
                      otp.length === i && styles.otpBoxActive 
                    ]}>
                      <Text style={styles.otpText}>{otp[i] || ""}</Text>
                    </View>
                  ))}
                </View>

                <TouchableOpacity style={[styles.mainBtn, {marginTop: 30}]} onPress={handleVerify}>
                  <Text style={styles.btnText}>Verify & {isSignup ? "Start" : "Login"}</Text>
                </TouchableOpacity>

              </View>
            )}
            
            {/* Footer */}
            <View style={{flex: 1, justifyContent: 'flex-end', marginBottom: 20}}>
              <Text style={styles.footerText}>A StampTrail Product</Text>
            </View>

          </View>
        </TouchableWithoutFeedback>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: THEME.bg },
  content: { flex: 1, paddingHorizontal: 20 },
  
  // Header
  backBtn: { marginTop: 10, marginBottom: 10 },
  headerArea: { alignItems: 'center', marginTop: 60, marginBottom: 40 },
  welcomeText: { color: 'white', fontSize: 16, fontWeight: '600', opacity: 0.9 },
  logoText: { color: THEME.accent, fontSize: 42, fontWeight: 'bold', letterSpacing: -1 },
  splashText: { color: 'white', marginTop: 20, fontSize: 18 },

  // Inputs
  phoneRow: { flexDirection: 'row', marginBottom: 20 },
  countryCode: { 
    backgroundColor: THEME.inputBg, width: 60, height: 55, 
    borderRadius: 8, justifyContent: 'center', alignItems: 'center', marginRight: 10
  },
  phoneInput: { 
    flex: 1, backgroundColor: THEME.inputBg, height: 55, 
    borderRadius: 8, paddingHorizontal: 15, fontSize: 18, color: 'white', fontWeight: 'bold'
  },
  inputText: { color: 'white', fontSize: 18, fontWeight: 'bold' },

  // Buttons
  mainBtn: { 
    backgroundColor: THEME.accent, height: 55, borderRadius: 30, 
    justifyContent: 'center', alignItems: 'center', marginBottom: 20
  },
  btnText: { color: '#004d40', fontSize: 18, fontWeight: 'bold' },

  // Toggle Section (Login vs Signup)
  toggleContainer: { flexDirection: 'row', justifyContent: 'center', marginTop: 30 },
  toggleText: { color: THEME.textSec, fontSize: 15 },
  toggleBtnText: { color: 'white', fontSize: 15, fontWeight: 'bold' },

  // Legal & Footer
  legalText: { color: THEME.textSec, fontSize: 12, textAlign: 'center', lineHeight: 18, marginTop: 10 },
  footerText: { color: 'white', textAlign: 'center', fontSize: 14, opacity: 0.5 },

  // OTP
  otpHeader: { color: 'white', fontSize: 20, textAlign: 'center', marginBottom: 30, fontWeight: '600' },
  otpContainer: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 30, position: 'relative' },
  otpBox: { width: 45, height: 55, backgroundColor: THEME.inputBg, borderRadius: 8, justifyContent: 'center', alignItems: 'center' },
  otpBoxActive: { borderColor: THEME.accent, borderWidth: 1 },
  otpText: { color: 'white', fontSize: 24, fontWeight: 'bold' },
  hiddenInput: { position: 'absolute', width: '100%', height: '100%', opacity: 0, zIndex: 10 },
});