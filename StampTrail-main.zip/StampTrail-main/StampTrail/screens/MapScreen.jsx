import React, { useState, useEffect, useRef } from 'react';
import { View, StyleSheet, Text, TouchableOpacity, Image, Dimensions, ActivityIndicator } from 'react-native';
import MapView, { Marker, Polyline, PROVIDER_DEFAULT } from 'react-native-maps';
import MapViewDirections from 'react-native-maps-directions'; 
import * as Location from 'expo-location';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { useIsFocused } from '@react-navigation/native'; 

//REPLACE THIS WITH YOUR GOOGLE MAPS API KEY FOR REAL ROADS
const GOOGLE_MAPS_APIKEY = "YOUR_API_KEY_HERE"; 

const THEME = {
  purple: '#6C4AB6',   
  accent: '#A0F0A0',   
  cardBg: '#8D72E1',   
  text: '#FFFFFF',
};

const { width } = Dimensions.get('window');

// Default View (San Francisco)
const DEFAULT_REGION = {
  latitude: 37.78825,
  longitude: -122.4324,
  latitudeDelta: 0.05,
  longitudeDelta: 0.05,
};

export default function MapScreen({ navigation }) {
  const isFocused = useIsFocused(); 
  const mapRef = useRef(null);

 
  const [hasPermission, setHasPermission] = useState(false);
  const [startLoc, setStartLoc] = useState(null);   
  const [destLoc, setDestLoc] = useState(null);     
  const [isNavigating, setIsNavigating] = useState(false);
  const [loading, setLoading] = useState(true);

  
  useEffect(() => {
    if (!isFocused) return; 

    (async () => {
      try {
        let { status } = await Location.requestForegroundPermissionsAsync();
        if (status === 'granted') {
          setHasPermission(true);
          let loc = await Location.getCurrentPositionAsync({});
          setStartLoc(loc.coords); 
        } else {
          
          setHasPermission(false);
        }
      } catch (e) {
        console.log("GPS Error", e);
      } finally {
        setLoading(false);
      }
    })();
  }, [isFocused]);

  
  const handleMapPress = (e) => {
    if (isNavigating) return; 

    const coords = e.nativeEvent.coordinate;

    
    if (!startLoc) {
      setStartLoc(coords);
      return;
    }

    
    setDestLoc({
      id: 'dest_pin',
      title: "Selected Destination",
      address: "Tap button to start",
      coords: coords
    });
  };

  const resetMap = () => {
    setIsNavigating(false);
    setDestLoc(null);
    if (!hasPermission) setStartLoc(null); 
  };

  const startNavigation = () => {
    if (!startLoc || !destLoc) return;
    setIsNavigating(true);
    
    
    mapRef.current.fitToCoordinates([startLoc, destLoc.coords], {
      edgePadding: { top: 100, right: 50, bottom: 200, left: 50 },
      animated: true,
    });
  };

  if (loading) {
    return <View style={styles.center}><ActivityIndicator color={THEME.purple}/></View>;
  }

  return (
    <View style={styles.container}>
      <MapView
        ref={mapRef}
        style={styles.map}
        initialRegion={startLoc ? {
          latitude: startLoc.latitude,
          longitude: startLoc.longitude,
          latitudeDelta: 0.01,
          longitudeDelta: 0.01,
        } : DEFAULT_REGION}
        showsUserLocation={hasPermission} 
        onPress={handleMapPress}
        provider={PROVIDER_DEFAULT}
      >
        
        
        {startLoc && (
          <Marker coordinate={startLoc} title="Start Point">
             <View style={styles.userDotContainer}>
                <View style={styles.userDot} />
                <View style={styles.userDotRing} />
             </View>
          </Marker>
        )}

       
        {destLoc && (
          <Marker coordinate={destLoc.coords}>
             <View style={styles.destMarker}>
                <View style={styles.destCenter} />
             </View>
          </Marker>
        )}

        
        {isNavigating && startLoc && destLoc && (
          GOOGLE_MAPS_APIKEY !== "YOUR_API_KEY_HERE" ? (
            <MapViewDirections
              origin={startLoc}
              destination={destLoc.coords}
              apikey={GOOGLE_MAPS_APIKEY}
              strokeWidth={4}
              strokeColor={THEME.cardBg}
            />
          ) : (
            
            <Polyline
              coordinates={[ startLoc, destLoc.coords ]}
              strokeColor={THEME.cardBg}
              strokeWidth={4}
              lineDashPattern={[5, 5]}
            />
          )
        )}
      </MapView>

      
      {!isNavigating && (
        <View style={styles.instructionBanner}>
          <Text style={styles.instructionText}>
            {!startLoc ? "Tap map to set START location" : 
             !destLoc ? "Tap map to set DESTINATION" : 
             "Ready to navigate!"}
          </Text>
        </View>
      )}

      {/* --- BOTTOM CONTROLS --- */}
      <View style={styles.bottomControls}>
        
        <View style={styles.toggleGroup}>
          <TouchableOpacity style={[styles.toggleBtn, styles.activeToggle]}>
            <Ionicons name="map" size={20} color={THEME.purple} />
          </TouchableOpacity>
          <TouchableOpacity 
            style={styles.toggleBtn} 
            onPress={() => navigation.navigate('ARScreen')}
          >
            <MaterialCommunityIcons name="augmented-reality" size={20} color="#888" />
          </TouchableOpacity>
        </View>

        {/* RESET BUTTON (Only if we pinned something) */}
        {(startLoc || destLoc) && !isNavigating && (
           <TouchableOpacity style={styles.resetButton} onPress={resetMap}>
             <Ionicons name="refresh" size={24} color="white" />
           </TouchableOpacity>
        )}

        {/* GO BUTTON */}
        {startLoc && destLoc && !isNavigating && (
           <TouchableOpacity style={styles.goButton} onPress={startNavigation}>
             <Ionicons name="navigate" size={28} color="white" style={{transform: [{rotate: '45deg'}]}} />
           </TouchableOpacity>
        )}
        
        {/* CANCEL BUTTON */}
        {isNavigating && (
           <TouchableOpacity style={styles.cancelButton} onPress={() => setIsNavigating(false)}>
             <Ionicons name="close" size={28} color="white" />
           </TouchableOpacity>
        )}
      </View>

      {/* --- INFO CARD --- */}
      {(destLoc || isNavigating) && (
        <View style={styles.infoCard}>
          <Image 
            source={{ uri: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?ixlib=rb-4.0.3&w=100&q=80' }} 
            style={styles.thumbnail} 
          />
          <View style={styles.textContainer}>
            {isNavigating && <Text style={styles.navHeader}>Navigating...</Text>}
            <Text style={styles.title}>{destLoc?.title || "New Location"}</Text>
            <Text style={styles.address}>{destLoc?.address || "Custom Pin"}</Text>
          </View>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  map: { width: '100%', height: '100%' },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  
  // Custom "Blue Dot"
  userDotContainer: { alignItems: 'center', justifyContent: 'center', width: 40, height: 40 },
  userDot: { width: 14, height: 14, borderRadius: 7, backgroundColor: '#4285F4', zIndex: 2 },
  userDotRing: { 
    position: 'absolute', width: 40, height: 40, borderRadius: 20, 
    backgroundColor: 'rgba(66, 133, 244, 0.2)', borderWidth: 1, borderColor: 'rgba(66, 133, 244, 0.4)' 
  },

  // Dest Marker
  destMarker: {
    width: 34, height: 34, borderRadius: 17,
    backgroundColor: 'rgba(108, 74, 182, 0.4)',
    justifyContent: 'center', alignItems: 'center',
    borderWidth: 1, borderColor: THEME.purple
  },
  destCenter: {
    width: 14, height: 14, borderRadius: 7,
    backgroundColor: THEME.purple,
    borderWidth: 2, borderColor: 'white'
  },

  // Instruction Banner
  instructionBanner: {
    position: 'absolute', top: 50, alignSelf: 'center',
    backgroundColor: 'rgba(0,0,0,0.7)', paddingHorizontal: 20, paddingVertical: 10,
    borderRadius: 20, zIndex: 5
  },
  instructionText: { color: 'white', fontWeight: 'bold' },

  bottomControls: {
    position: 'absolute', bottom: 40, 
    width: '100%', flexDirection: 'row', 
    justifyContent: 'space-between', paddingHorizontal: 20,
    alignItems: 'flex-end', zIndex: 10
  },
  toggleGroup: {
    flexDirection: 'row', backgroundColor: 'white',
    borderRadius: 12, padding: 6, elevation: 5, marginBottom: 5
  },
  toggleBtn: { padding: 10, borderRadius: 8, marginHorizontal: 2 },
  activeToggle: { backgroundColor: '#F0EFFB' },

  goButton: {
    backgroundColor: THEME.purple, width: 60, height: 60, borderRadius: 30, 
    justifyContent: 'center', alignItems: 'center', elevation: 8
  },
  cancelButton: {
    backgroundColor: '#333', width: 60, height: 60, borderRadius: 30, 
    justifyContent: 'center', alignItems: 'center', elevation: 8
  },
  resetButton: {
    backgroundColor: '#FF6B6B', width: 50, height: 50, borderRadius: 25, 
    justifyContent: 'center', alignItems: 'center', elevation: 5, marginRight: 10, marginBottom: 5
  },

  infoCard: {
    position: 'absolute', bottom: 120, alignSelf: 'center',
    width: width - 40, backgroundColor: THEME.cardBg,
    borderRadius: 15, flexDirection: 'row', padding: 15,
    elevation: 10
  },
  thumbnail: { width: 60, height: 60, borderRadius: 10, marginRight: 15, backgroundColor: '#666' },
  textContainer: { flex: 1, justifyContent: 'center' },
  navHeader: { color: THEME.accent, fontSize: 12, fontWeight: 'bold', marginBottom: 2, textTransform: 'uppercase' },
  title: { color: 'white', fontSize: 18, fontWeight: 'bold' },
  address: { color: '#E0E0E0', fontSize: 14 },
});