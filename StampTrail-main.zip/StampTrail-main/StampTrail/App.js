
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { StatusBar } from 'expo-status-bar';


import MapScreen from '../StampTrail/screens/MapScreen';
import LoginScreen from '../StampTrail/screens/LoginScreen';
import SignupDetailsScreen from '../StampTrail/screens/SignupDetailsScreen';
import ARScreen from '../StampTrail/screens/ARScreen';


const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <StatusBar style="auto" />
      <Stack.Navigator initialRouteName="Login" screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Login" component={LoginScreen} />
        <Stack.Screen name="SignupDetails" component={SignupDetailsScreen} />
        <Stack.Screen name="MapScreen" component={MapScreen} />
        <Stack.Screen name="ARScreen" component={ARScreen} />

      </Stack.Navigator>
    </NavigationContainer>
  );
}